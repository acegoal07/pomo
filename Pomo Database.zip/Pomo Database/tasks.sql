INSERT INTO tasks (taskID, username, taskContent) VALUES (24, 'caroline', 'Do my homework');
INSERT INTO tasks (taskID, username, taskContent) VALUES (107, 'dara', 'Test');
INSERT INTO tasks (taskID, username, taskContent) VALUES (108, 'dara', 'Complete computing project');
INSERT INTO tasks (taskID, username, taskContent) VALUES (109, 'dara', 'Finish Math homework');
INSERT INTO tasks (taskID, username, taskContent) VALUES (115, 'abbie', 'test');
