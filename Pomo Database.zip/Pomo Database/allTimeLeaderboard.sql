INSERT INTO allTimeLeaderboard (username, fullPomoScore) VALUES ('dara', 12);
INSERT INTO allTimeLeaderboard (username, fullPomoScore) VALUES ('jeff', 9);
INSERT INTO allTimeLeaderboard (username, fullPomoScore) VALUES ('alan', 7);
INSERT INTO allTimeLeaderboard (username, fullPomoScore) VALUES ('jchan', 6);
INSERT INTO allTimeLeaderboard (username, fullPomoScore) VALUES ('abbie', 6);
