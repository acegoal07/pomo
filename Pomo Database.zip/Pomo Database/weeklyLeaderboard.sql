INSERT INTO weeklyLeaderboard (username, scoreDifference) VALUES ('dara', '10');
INSERT INTO weeklyLeaderboard (username, scoreDifference) VALUES ('alex', '4');
INSERT INTO weeklyLeaderboard (username, scoreDifference) VALUES ('eMan', '4');
INSERT INTO weeklyLeaderboard (username, scoreDifference) VALUES ('abbie', '3');
INSERT INTO weeklyLeaderboard (username, scoreDifference) VALUES ('alan', '2');
